#ifndef logout_h
#define logout_h
using namespace std;

class Logout
{
      public:
      
	    void Logout_message();
};

#endif                
