#ifndef clean_stdin_h
#define clean_stdin_h

void clean_stdin(void);

#endif
