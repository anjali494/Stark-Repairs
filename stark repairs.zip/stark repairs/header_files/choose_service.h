#ifndef choose_service_h
#define choose_service_h

using namespace std;

class Choose_Service
{
      private:
            int ch;
      public:
            int choice();
};

#endif
