#ifndef invoice_h
#define invoice_h

#include "signup.h"
#include "service_details.h"
#include "payment.h"
using namespace std;

void display_invoice(Signup S,Service_Details SD,Payment p);

#endif
