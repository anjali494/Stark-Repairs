#include <iostream>
#include "../header_files/logout.h"
using namespace std;


      void Logout::Logout_message()
      {
	   cout<<"\n  You have successfully logged out !!";	
           cout<<"\n\n  Thank you, our service agent will be soon in touch with you";
      }
