#include <iostream>
#include "../header_files/choose_service.h"
using namespace std;

      int Choose_Service::choice()
      {
            cout<<"\n  Enter your choice: ";
            cin>>ch;

            return ch;
      }
      
